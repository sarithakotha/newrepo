﻿using System;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using PurchReqV2.Controllers;
using PurchReqV2.Models.Entities;
using PurchReqV2.Utilities;
using MenuItem = PurchReqV2.Models.Entities.PurchReq_MenuItem;

namespace PurchReqV2
{
    public partial class SiteAdmin : PurchReqV2BasePage
    {
        #region Variables

        #region Public Variables

        #endregion

        #region Private Variables

        private SiteAdminController _controller;

        #endregion

        #endregion

        #region Methods

        #region Public/Protected Methods

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.Title = "Purchase Requisitions - Website Administration";
                _controller = new SiteAdminController(HttpContext.Current.User.Identity.Name);
                Response.Cache.SetNoStore();
                Response.Cache.AppendCacheExtension("no-cache");
                if (IsPostBack) return;
                gvMenuItems.DataBind();
                SetupSiteMaintenanceSection();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #region Add MenuItem Section

        /// <summary>
        /// Handles the ContextCreating event of the ldsMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsMenuItems_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsMenuItems_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetMenuItems(string.IsNullOrEmpty(txtFilterMenuItemsByName.Text) ? null : txtFilterMenuItemsByName.Text);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnInserting event of the ldsMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceInsertEventArgs"/> instance containing the event data.</param>
        protected void ldsMenuItems_OnInserting(object sender, LinqDataSourceInsertEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertMenuItem(e.NewObject);
                ddlMenuItemParent.Items.Clear();
                ddlMenuItemParent.DataBind();
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnUpdating event of the ldsMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceUpdateEventArgs"/> instance containing the event data.</param>
        protected void ldsMenuItems_OnUpdating(object sender, LinqDataSourceUpdateEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }

                UpsertMenuItem(e.NewObject);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnDeleting event of the ldsMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceDeleteEventArgs"/> instance containing the event data.</param>
        protected void ldsMenuItems_OnDeleting(object sender, LinqDataSourceDeleteEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertMenuItem(e.OriginalObject, true);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnDataBinding event of the txtGvMenuItemName control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void txtGvMenuItemName_OnDataBinding(object sender, EventArgs e)
        {
            try
            {
                var txtGvMenuItemName = sender as TextBox;
                if (txtGvMenuItemName == null) return;
                ViewState["txtGvMenuItemName"] = txtGvMenuItemName.Text;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnDataBinding event of the txtGvMenuItemUrl control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void txtGvMenuItemUrl_OnDataBinding(object sender, EventArgs e)
        {
            try
            {
                var txtGvMenuItemUrl = sender as TextBox;
                if (txtGvMenuItemUrl == null) return;
                ViewState["txtGvMenuItemUrl"] = txtGvMenuItemUrl.Text;
            }
            catch (Exception ee) { HandleException(ee); }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlMenuItemId control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlMenuItemId_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetMenuItems().Select(result => new Models.MenuItem
                {
                    MenuItemId = result.MenuItemID,
                    MenuItemParentId = result.MenuItemParentID,
                    Text = result.Text + " - " + result.Description,
                    Url = result.Url,
                    IsHeader = result.IsHeader,
                    Description = result.Description
                }).ToList();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupAddMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupAddMenuItem_OnClick(object sender, EventArgs e)
        {
            try
            {
                Page.Validate("popupMenuItem");
                if (!IsValid)
                {
                    var mpe = Extensions.FindControlRecursive(Page, "mpeAddMenuItem") as ModalPopupExtender;
                    if (mpe == null) return;
                    mpe.EnsureValid();
                    mpe.Show();
                    return;
                }

                var menuItemParentId = string.IsNullOrEmpty(ddlMenuItemParent.SelectedValue)
                    ? new long?()
                    : Convert.ToInt64(ddlMenuItemParent.SelectedValue);
                var menuItem = new MenuItem
                {
                    MenuItemParentID = menuItemParentId,
                    Text = txtMenuItemName.Text,
                    Url = txtMenuItemUrl.Text,
                    Description = txtMenuItemDescription.Text,
                    IsHeader = cbMenuItemIsHeader.Checked,
                    Active = cbMenuItemActive.Checked
                };
                UpsertMenuItem(menuItem);
                ClearMenuItemPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupCancelAddMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupCancelAddMenuItem_OnClick(object sender, EventArgs e)
        {
            try
            {
                ClearMenuItemPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnFilterMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnFilterMenuItems_OnClick(object sender, EventArgs e)
        {
            try
            {
                gvMenuItems.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnCancelFilterMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnCancelFilterMenuItems_OnClick(object sender, EventArgs e)
        {
            try
            {
                txtFilterMenuItemsByName.Text = "";
                gvMenuItems.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnServerValidate event of the Url control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="ServerValidateEventArgs"/> instance containing the event data.</param>
        protected void Url_OnServerValidate(object sender, ServerValidateEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(e.Value))
                {
                    e.IsValid = true;
                    return;
                }
                var cv = sender as CustomValidator;
                if (cv == null)
                {
                    e.IsValid = false;
                    return;
                }

                var menuItems = _controller.GetMenuItems();
                var oldValue = ViewState["txtGvMenuItemUrl"] != null
                    ? ViewState["txtGvMenuItemUrl"].ToString().ToLower()
                    : "";

                if (string.Equals(e.Value.ToLower(), oldValue, StringComparison.InvariantCultureIgnoreCase))
                {
                    e.IsValid = true;
                    return;
                }

                Uri uri;

                if (!Uri.TryCreate(e.Value, UriKind.Relative, out uri) || !uri.IsWellFormedOriginalString())
                {
                    cv.ErrorMessage =
                        "The URL must match a pattern that can be mapped to a server file.  A good example to use is: '~/{SomePath}/{SomePath}.{SomeExtension}'; however, any valid URI will work.";
                    e.IsValid = false;
                    return;
                }

                if (!File.Exists(Server.MapPath(uri.OriginalString)))
                {
                    cv.ErrorMessage =
                        "The URL must exist on the server for verification purposes.  The given URL, " + e.Value +
                        ", cannot be mapped to as a file on the server.";
                    e.IsValid = false;
                    return;
                }

                var input = Path.GetFileNameWithoutExtension(Server.MapPath(e.Value.Trim('/').ToLower()));
                if (
                    menuItems.Any(
                    item => input == Path.GetFileNameWithoutExtension(Server.MapPath(item.Url == null ? "" : item.Url.Trim('/').ToLower()))))
                {
                    cv.ErrorMessage =
                        "The URL must be unique.  The given URL, " + e.Value +
                        ", matches a URL already associated with a Menu Item.";
                    e.IsValid = false;
                    return;
                }

                e.IsValid = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnServerValidate event of the Name control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="ServerValidateEventArgs"/> instance containing the event data.</param>
        protected void Name_OnServerValidate(object sender, ServerValidateEventArgs e)
        {
            try
            {
                var cv = sender as CustomValidator;
                if (cv == null) return;
                var menuItems = _controller.GetMenuItems();

                var input = e.Value.ToLower();
                var oldValue = ViewState["txtGvMenuItemName"] != null
                    ? ViewState["txtGvMenuItemName"].ToString().ToLower()
                    : "";

                if (string.Equals(e.Value.ToLower(), oldValue, StringComparison.InvariantCultureIgnoreCase))
                {
                    e.IsValid = true;
                    return;
                }

                if (menuItems.Any(item => input == item.Text.ToLower()))
                {
                    cv.ErrorMessage =
                        "The Name of the Menu Item must be unique.  The given Name, " + e.Value +
                        ", is already associated with a Menu Item.";
                    e.IsValid = false;
                    return;
                }

                e.IsValid = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnSaveMaintenance control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnSaveMaintenance_OnClick(object sender, EventArgs e)
        {
            try
            {
                var estimatedEndTime = string.IsNullOrEmpty(txtEstimatedEndDateTime.Text)
                    ? Convert.ToDateTime(SqlDateTime.MinValue.ToString())
                    : Convert.ToDateTime(txtEstimatedEndDateTime.Text);
                _controller.UpsertSiteMaintenance(cbMaintenanceMode.Checked, estimatedEndTime,
                    HttpContext.Current.User.Identity.Name);
                HideMaintenanceControls();
                DisposeMaintenanceControls();
                HideSiteMaintenanceButtons();
                if (cbMaintenanceMode.Checked)
                {
                    DisplayMessage("Maintenance Mode Activated On " + DateTime.Now.ToString("g") + ".",
                        MessageType.Success);
                    Session["adminSiteMaintenance"] = GetSiteMaintenanceInformation();
                }
                else
                {
                    DisplayMessage("Maintenance Mode Deactivated On " + DateTime.Now.ToString("g") + ".",
                        MessageType.Success);
                    Session["adminSiteMaintenance"] = null;
                }
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnCancelMaintenance control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnCancelMaintenance_OnClick(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect(Request.Url.ToString());
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnCheckedChanged event of the cbMaintenanceMode control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void cbMaintenanceMode_OnCheckedChanged(object sender, EventArgs e)
        {
            try
            {
                var div = Extensions.FindControlRecursive(Page, "divMaintenanceDisabled");
                if (div == null) return;
                var cb = sender as CheckBox;
                if (cb == null) return;
                var divBtns = Extensions.FindControlRecursive(Page, "divMaintenanceButtons");
                if (divBtns == null) return;
                var siteMaintenance = Session["adminSiteMaintenance"] as Models.SiteMaintenance;

                if (siteMaintenance != null && siteMaintenance.Active)
                {
                    div.Visible = false;
                    divBtns.Visible = true;
                    return;
                }
                else if (siteMaintenance == null && cb.Checked)
                {
                    div.Visible = true;
                    divBtns.Visible = true;
                    return;
                }
                if (siteMaintenance == null && !cb.Checked)
                {
                    div.Visible = false;
                    divBtns.Visible = false;
                    return;
                }

                div.Visible = false;
                txtEstimatedEndDateTime.Text = "";
                divBtns.Visible = true;
            }
            catch (Exception ee) { HandleException(ee); }
        }

        #endregion

        #region Add Configuration Section

        /// <summary>
        /// Handles the ContextCreating event of the ldsConfigurations control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsConfigurations_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsConfigurations control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsConfigurations_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetConfigurations(string.IsNullOrEmpty(txtFilterConfigurationsByName.Text) ? null : txtFilterConfigurationsByName.Text);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnUpdating event of the ldsConfigurations control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceUpdateEventArgs"/> instance containing the event data.</param>
        protected void ldsConfigurations_OnUpdating(object sender, LinqDataSourceUpdateEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }

                UpsertConfiguration(e.NewObject);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnDeleting event of the ldsConfigurations control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceDeleteEventArgs"/> instance containing the event data.</param>
        protected void ldsConfigurations_OnDeleting(object sender, LinqDataSourceDeleteEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertConfiguration(e.OriginalObject, true);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnFilterConfigurations control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnFilterConfigurations_OnClick(object sender, EventArgs e)
        {
            try
            {
                gvConfigurations.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnCancelFilterConfigurations control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnCancelFilterConfigurations_OnClick(object sender, EventArgs e)
        {
            try
            {
                txtFilterConfigurationsByName.Text = "";
                gvConfigurations.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupAddConfiguration control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupAddConfiguration_OnClick(object sender, EventArgs e)
        {
            try
            {
                Page.Validate("popupConfiguration");
                if (!IsValid)
                {
                    var mpe = Extensions.FindControlRecursive(Page, "mpeAddConfiguration") as ModalPopupExtender;
                    if (mpe == null) return;
                    mpe.Show();
                    return;
                }

                var config = new PurchReq_Configuration
                {
                    Process = txtProcess.Text,
                    ConfigName = txtConfigurationName.Text,
                    ConfigValue = txtConfigurationValue.Text,
                    DataTypeID = Convert.ToInt64(ddlNetDataType.SelectedValue),
                    Length = string.IsNullOrEmpty(txtLength.Text) ? (long?)null : Convert.ToInt64(txtLength.Text),
                    Active = cbConfigurationActive.Checked,
                    ModifiedBy = HttpContext.Current.User.Identity.Name
                };

                UpsertConfiguration(config);
                ClearConfigurationPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupCancelAddConfiguration control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupCancelAddConfiguration_OnClick(object sender, EventArgs e)
        {
            try
            {
                ClearConfigurationPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlConfigurationName control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlConfigurationName_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetConfigurations();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsCDataType control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsCDataType_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetCDataTypes();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnServerValidate event of the GvConfiguration control.
        /// </summary>
        /// <param name="source">The source of the event.</param>
        /// <param name="args">The <see cref="ServerValidateEventArgs"/> instance containing the event data.</param>
        protected void GvConfiguration_OnServerValidate(object source, ServerValidateEventArgs args)
        {
            try
            {
                var netDataType = Extensions.FindControlRecursive(Page, "ddlGvNetDataType") as DropDownList;
                var cv = source as CustomValidator;

                if (netDataType == null || cv == null) return;

                var type = Type.GetType(netDataType.SelectedItem.Text);

                if (type == null)
                {
                    cv.ErrorMessage =
                        "There seems to be an issue -- an underlying CLR Type cannot be created from the selected .NET Data Type, meaning it is invalid.  Please have this type corrected in the database and try again.";
                    args.IsValid = false;
                    return;
                }

                try
                {
                    var converter = TypeDescriptor.GetConverter(type);
                    var result = converter.ConvertFrom(args.Value);
                    if (result == null)
                    {
                        cv.ErrorMessage = "There seems to be an issue; the Configuration Value \"" + args.Value +
                                          "\" cannot be converted into the selected CLR .NET Data Type \"" +
                                          netDataType.SelectedItem.Text + "\".  Please select a valid type and try again.";
                        args.IsValid = false;
                        return;
                    }
                    args.IsValid = result.GetType() == type;
                }
                catch (Exception)
                {
                    cv.ErrorMessage = "There seems to be an issue; the Configuration Value \"" + args.Value +
                                      "\" cannot be converted into the selected CLR .NET Data Type \"" +
                                      netDataType.SelectedItem.Text + "\".  Please select a valid type and try again.";
                    args.IsValid = false;
                }
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnServerValidate event of the Configuration control.
        /// </summary>
        /// <param name="source">The source of the event.</param>
        /// <param name="args">The <see cref="ServerValidateEventArgs"/> instance containing the event data.</param>
        protected void Configuration_OnServerValidate(object source, ServerValidateEventArgs args)
        {
            try
            {
                var cv = source as CustomValidator;

                if (ddlNetDataType == null || cv == null) return;

                var type = Type.GetType(ddlNetDataType.SelectedItem.Text);

                if (type == null)
                {
                    cv.ErrorMessage =
                        "There seems to be an issue -- an underlying CLR Type cannot be created from the selected .NET Data Type, meaning it is invalid.  Please have this type corrected in the database and try again.";
                    args.IsValid = false;
                    return;
                }

                try
                {
                    var converter = TypeDescriptor.GetConverter(type);
                    var result = converter.ConvertFrom(args.Value);
                    if (result == null)
                    {
                        cv.ErrorMessage = "There seems to be an issue; the Configuration Value \"" + args.Value +
                                          "\" cannot be converted into the selected CLR .NET Data Type \"" +
                                          ddlNetDataType.SelectedItem.Text + "\".  Please select a valid type and try again.";
                        args.IsValid = false;
                        return;
                    }
                    args.IsValid = result.GetType() == type;
                }
                catch (Exception)
                {
                    cv.ErrorMessage = "There seems to be an issue; the Configuration Value \"" + args.Value +
                                      "\" cannot be converted into the selected CLR .NET Data Type \"" +
                                      ddlNetDataType.SelectedItem.Text + "\".  Please select a valid type and try again.";
                    args.IsValid = false;
                }
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #endregion

        #endregion

        #region Private Methods

        private void UpsertMenuItem(object e, bool? delete = false)
        {
            _controller.UpsertMenuItem(e, delete);
            gvMenuItems.DataBind();
            ddlMenuItemParent.Items.Clear();
            ddlMenuItemParent.Items.Add(new ListItem("No Parent Menu Item", ""));
            ddlMenuItemParent.DataBind();
            DisplayMessage("Success!", MessageType.Success);
        }

        private void ClearMenuItemPopup()
        {
            txtMenuItemName.Text = "";
            cbMenuItemIsHeader.Checked = false;
            txtMenuItemDescription.Text = "";
            txtMenuItemUrl.Text = "";
            cbMenuItemActive.Checked = true;
        }

        private void SetupSiteMaintenanceSection()
        {
            var cb = Extensions.FindControlRecursive(Page, "cbMaintenanceMode") as CheckBox;
            if (cb == null) return;
            var divDisabled = Extensions.FindControlRecursive(Page, "divMaintenanceDisabled");
            if (divDisabled == null) return;
            var divButtons = Extensions.FindControlRecursive(Page, "divMaintenanceButtons");
            if (divButtons == null) return;

            var siteMaintenance = GetSiteMaintenanceInformation();
            divButtons.Visible = true;
            HideSiteMaintenanceButtons();
            cb.Checked = siteMaintenance.Active;
            txtEstimatedEndDateTime.Text = siteMaintenance.EstimatedEndTime.ToString("G");
            if (!siteMaintenance.Active) return;
            DisposeMaintenanceControls();
            Session["adminSiteMaintenance"] = siteMaintenance;
        }

        private void DisposeMaintenanceControls()
        {
            var divDisabled = Extensions.FindControlRecursive(Page, "divMaintenanceDisabled");
            if (divDisabled == null) return;
            divDisabled.Dispose();
        }

        private void HideMaintenanceControls()
        {
            var divDisabled = Extensions.FindControlRecursive(Page, "divMaintenanceDisabled");
            if (divDisabled == null) return;
            divDisabled.Visible = false;
        }

        private void HideSiteMaintenanceButtons()
        {
            var divButtons = Extensions.FindControlRecursive(Page, "divMaintenanceButtons");
            if (divButtons == null) return;
            divButtons.Visible = false;
        }

        private void UpsertConfiguration(object e, bool? delete = false)
        {
            _controller.UpsertConfiguration(e, delete);
            gvConfigurations.DataBind();
            DisplayMessage("Success!", MessageType.Success);
        }

        private void ClearConfigurationPopup()
        {
            txtProcess.Text = "";
            txtConfigurationName.Text = "";
            txtConfigurationValue.Text = "";
            ddlNetDataType.SelectedIndex = -1;
            txtLength.Text = "";
            cbConfigurationActive.Checked = true;
        }

        #endregion

        #endregion
    }
}