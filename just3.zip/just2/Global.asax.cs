﻿using System;
using System.Threading;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using PurchReqV2.Models.Entities;
using PurchReqV2.Utilities;

namespace PurchReqV2
{
    /// <summary>
    /// Global Application event handlers
    /// </summary>
    /// <seealso cref="System.Web.HttpApplication" />
    public class Global : HttpApplication
    {
        /// <summary>
        /// Handles the Start event of the Application control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        void Application_Start(object sender, EventArgs e)
        {
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }


        /// <summary>
        /// Handles the Error event of the Application control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        void Application_Error(object sender, EventArgs e)
        {
            var ex = Server.GetLastError();
            if (ex == null) { return; }
            if (ex is ThreadAbortException || ex is HttpUnhandledException) return;
            try
            {
                Application[Config.SessionException] = ex;
                Application[Config.SessionStackTrace] = ex.StackTrace;
                Application[Config.SessionErrorMessage] = ex.Message;
                Response.Redirect(Config.ErrorPage);
            }
            catch { }
        }

        /// <summary>
        /// Handles the EndRequest event of the Application control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Application_EndRequest(object sender, EventArgs e)
        {
            try
            {
                var context = HttpContext.Current;
                if (!context.Response.Status.Substring(0, 3).Equals("401")) return;
                context.Response.ClearContent();
                context.Response.Write("<script language=\"javascript\">" +
                                                                    "self.location='" + Server.MapPath(Config.FourZeroOnePage) + "';</script>");
            }
            catch { }
        }

        /// <summary>
        /// Handles the End event of the Session control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="E">The <see cref="EventArgs"/> instance containing the event data.</param>
        void Session_End(Object sender, EventArgs E)
        {
            try
            {
                var controller = new Controllers.PurchaseRequisitionsController(Config.LdapUser);
                controller.DeleteStagedPurchaseRequisitionsBySessionID(Session.SessionID);
            }
            catch { }
        }
    }
}