﻿using System;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using PurchReqV2.Controllers;
using PurchReqV2.Models.Entities;
using PurchReqV2.Utilities;
using Group = PurchReqV2.Models.Entities.PurchReq_Group;
using User = PurchReqV2.Models.Entities.PurchReq_User;

namespace PurchReqV2
{
    /// <summary>
    /// User Admin Page
    /// </summary>
    /// <seealso cref="PurchReqV2.PurchReqV2BasePage" />
    public partial class UserAdmin : PurchReqV2BasePage
    {
        #region Variables

        #region Public Variables

        #endregion

        #region Private Variables

        private UserAdminController _controller;

        #endregion

        #endregion

        #region Methods

        #region Public/Protected Methods

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.Title = "Purchase Requisitions - User Administration";
                _controller = new UserAdminController(HttpContext.Current.User.Identity.Name);
                if (IsPostBack) return;
                gvUsers.DataBind();
                gvGroups.DataBind();
                gvUserMenuItems.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #region Add User Section

        /// <summary>
        /// Handles the ContextCreating event of the ldsUsers control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsUsers_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsUsers control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsUsers_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetUsers(string.IsNullOrEmpty(txtFilterUsersByName.Text)
                        ? null
                        : txtFilterUsersByName.Text);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnInserting event of the ldsUsers control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceInsertEventArgs"/> instance containing the event data.</param>
        protected void ldsUsers_OnInserting(object sender, LinqDataSourceInsertEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertUser(e.NewObject);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnUpdating event of the ldsUsers control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceUpdateEventArgs"/> instance containing the event data.</param>
        protected void ldsUsers_OnUpdating(object sender, LinqDataSourceUpdateEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertUser(e.NewObject);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnDeleting event of the ldsUsers control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceDeleteEventArgs"/> instance containing the event data.</param>
        protected void ldsUsers_OnDeleting(object sender, LinqDataSourceDeleteEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertUser(e.OriginalObject, true);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupAddUser control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupAddUser_OnClick(object sender, EventArgs e)
        {
            try
            {
                var user = new User { UserName = txtUserName.Text, IsAdmin = cbUserIsAdmin.Checked, Active = cbUserActive.Checked };
                UpsertUser(user);
                ClearUserPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupCancelAddUser control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupCancelAddUser_OnClick(object sender, EventArgs e)
        {
            try
            {
                ClearUserPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnFilterUsers control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnFilterUsers_OnClick(object sender, EventArgs e)
        {
            try
            {
                gvUsers.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnCancelFilterUsers control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnCancelFilterUsers_OnClick(object sender, EventArgs e)
        {
            try
            {
                txtFilterUsersByName.Text = "";
                gvUsers.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #endregion

        #region Add Group Methods

        /// <summary>
        /// Handles the ContextCreating event of the ldsGroups control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsGroups_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsGroups control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsGroups_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetGroups(string.IsNullOrEmpty(txtFilterGroupsByName.Text)
                        ? null
                        : txtFilterGroupsByName.Text);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnInserting event of the ldsGroups control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceInsertEventArgs"/> instance containing the event data.</param>
        protected void ldsGroups_OnInserting(object sender, LinqDataSourceInsertEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertGroup(e.NewObject);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnUpdating event of the ldsGroups control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceUpdateEventArgs"/> instance containing the event data.</param>
        protected void ldsGroups_OnUpdating(object sender, LinqDataSourceUpdateEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertGroup(e.NewObject);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnDeleting event of the ldsGroups control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceDeleteEventArgs"/> instance containing the event data.</param>
        protected void ldsGroups_OnDeleting(object sender, LinqDataSourceDeleteEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertGroup(e.OriginalObject, true);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupAddGroup control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupAddGroup_OnClick(object sender, EventArgs e)
        {
            try
            {
                var group = new Group { ADGroup = txtGroupName.Text, IsAdmin = cbGroupIsAdmin.Checked, Active = cbGroupActive.Checked };
                UpsertGroup(group);
                ClearGroupPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupCancelAddGroup control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupCancelAddGroup_OnClick(object sender, EventArgs e)
        {
            try
            {
                ClearGroupPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnFilterGroups control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnFilterGroups_OnClick(object sender, EventArgs e)
        {
            try
            {
                gvGroups.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnCancelFilterGroups control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnCancelFilterGroups_OnClick(object sender, EventArgs e)
        {
            try
            {
                txtFilterGroupsByName.Text = "";
                gvGroups.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #endregion

        #region Add UserMenuItem Methods

        /// <summary>
        /// Handles the ContextCreating event of the ldsUserMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsUserMenuItems_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsUserMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsUserMenuItems_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                var c = _controller.GetUserMenuItems();
                e.Result = _controller.GetUserMenuItems(string.IsNullOrEmpty(txtFilterUserMenuItemsByName.Text)
                        ? null
                        : txtFilterUserMenuItemsByName.Text);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnInserting event of the ldsUserMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceInsertEventArgs"/> instance containing the event data.</param>
        protected void ldsUserMenuItems_OnInserting(object sender, LinqDataSourceInsertEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertUserMenuItem(e.NewObject);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnUpdating event of the ldsUserMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceUpdateEventArgs"/> instance containing the event data.</param>
        protected void ldsUserMenuItems_OnUpdating(object sender, LinqDataSourceUpdateEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }

                UpsertUserMenuItem(e.NewObject);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnDeleting event of the ldsUserMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceDeleteEventArgs"/> instance containing the event data.</param>
        protected void ldsUserMenuItems_OnDeleting(object sender, LinqDataSourceDeleteEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertUserMenuItem(e.OriginalObject, true);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnDataBound event of the gvUserMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void gvUserMenuItems_OnDataBound(object sender, EventArgs e)
        {
            try
            {
                gvUserMenuItems.Columns[Extensions.GetColumnIndexByName(gvUserMenuItems, "URL")].Visible = gvUserMenuItems.EditIndex <= -1;
                gvUserMenuItems.Columns[Extensions.GetColumnIndexByName(gvUserMenuItems, "Description")].Visible = gvUserMenuItems.EditIndex <= -1;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlUserMenuItemUserId control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlUserMenuItemUserId_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetUsers();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlUserMenuItemId control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlUserMenuItemId_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetMenuItems().Select(result => new Models.MenuItem
                {
                    MenuItemId = result.MenuItemId,
                    MenuItemParentId = result.MenuItemParentId,
                    Text = result.Text + " - " + result.Description,
                    Url = result.Url,
                    IsHeader = result.IsHeader,
                    Description = result.Description
                }).ToList();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupAddUserMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupAddUserMenuItem_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (ddlUserMenuItemName.SelectedItem == null)
                {
                    DisplayMessage(
                        "A Menu Item must be selected to add a new User Menu Item  Please select a Menu Item.",
                        MessageType.Error);
                    return;
                }
                if (ddlUserMenuItemUserName.SelectedItem == null)
                {
                    DisplayMessage("A User must be selected to associate the Menu Item with  Please select a User.",
                        MessageType.Error);
                    return;
                }

                var userMenuItem = new PurchReq_UserMenuItem
                {
                    UserMenuItemsID = 0,
                    UserID = Convert.ToInt64(ddlUserMenuItemUserName.SelectedValue),
                    Active = cbUserMenuItemActive.Checked,
                    MenuItemID = Convert.ToInt64(ddlUserMenuItemName.SelectedValue)
                };
                UpsertUserMenuItem(userMenuItem);
                ClearUserMenuItemPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupCancelAddUserMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupCancelAddUserMenuItem_OnClick(object sender, EventArgs e)
        {
            try
            {
                ClearUserMenuItemPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnFilterUserMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnFilterUserMenuItems_OnClick(object sender, EventArgs e)
        {
            try
            {
                gvUserMenuItems.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnCancelFilterUserMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnCancelFilterUserMenuItems_OnClick(object sender, EventArgs e)
        {
            try
            {
                txtFilterUserMenuItemsByName.Text = "";
                gvUserMenuItems.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #endregion

        #region Add GroupMenuItem Section

        /// <summary>
        /// Handles the ContextCreating event of the ldsGroupMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsGroupMenuItems_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsGroupMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsGroupMenuItems_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetGroupMenuItems(string.IsNullOrEmpty(txtFilterGroupMenuItemsByName.Text)
                        ? null
                        : txtFilterGroupMenuItemsByName.Text);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnInserting event of the ldsGroupMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceInsertEventArgs"/> instance containing the event data.</param>
        protected void ldsGroupMenuItems_OnInserting(object sender, LinqDataSourceInsertEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertGroupMenuItem(e.NewObject);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnUpdating event of the ldsGroupMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceUpdateEventArgs"/> instance containing the event data.</param>
        protected void ldsGroupMenuItems_OnUpdating(object sender, LinqDataSourceUpdateEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }

                UpsertGroupMenuItem(e.NewObject);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnDeleting event of the ldsGroupMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceDeleteEventArgs"/> instance containing the event data.</param>
        protected void ldsGroupMenuItems_OnDeleting(object sender, LinqDataSourceDeleteEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                UpsertGroupMenuItem(e.OriginalObject, true);
                e.Cancel = true;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnDataBound event of the gvGroupMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void gvGroupMenuItems_OnDataBound(object sender, EventArgs e)
        {
            try
            {
                gvGroupMenuItems.Columns[Extensions.GetColumnIndexByName(gvGroupMenuItems, "URL")].Visible = gvGroupMenuItems.EditIndex <= -1;
                gvGroupMenuItems.Columns[Extensions.GetColumnIndexByName(gvGroupMenuItems, "Description")].Visible = gvGroupMenuItems.EditIndex <= -1;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlGroupMenuItemGroupId control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlGroupMenuItemGroupId_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetGroups();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlGroupMenuItemId control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlGroupMenuItemId_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetMenuItems().Select(result => new Models.MenuItem
                {
                    MenuItemId = result.MenuItemId,
                    MenuItemParentId = result.MenuItemParentId,
                    Text = result.Text + " - " + result.Description,
                    Url = result.Url,
                    IsHeader = result.IsHeader,
                    Description = result.Description
                }).ToList();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupAddGroupMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupAddGroupMenuItem_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (ddlGroupMenuItemName.SelectedItem == null)
                {
                    DisplayMessage(
                        "A Menu Item must be selected to add a new Group Menu Item  Please select a Menu Item.",
                        MessageType.Error);
                    return;
                }
                if (ddlGroupMenuItemGroupName.SelectedItem == null)
                {
                    DisplayMessage("A Group must be selected to associate the Menu Item with  Please select a Group.",
                        MessageType.Error);
                    return;
                }

                var groupMenuItem = new PurchReq_GroupMenuItem
                {
                    GroupMenuItemsID = 0,
                    GroupID = Convert.ToInt64(ddlGroupMenuItemGroupName.SelectedValue),
                    Active = cbGroupMenuItemActive.Checked,
                    MenuItemID = Convert.ToInt64(ddlGroupMenuItemName.SelectedValue)
                };
                UpsertGroupMenuItem(groupMenuItem);
                ClearGroupMenuItemPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupCancelAddGroupMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupCancelAddGroupMenuItem_OnClick(object sender, EventArgs e)
        {
            try
            {
                ClearGroupMenuItemPopup();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnFilterGroupMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnFilterGroupMenuItems_OnClick(object sender, EventArgs e)
        {
            try
            {
                gvGroupMenuItems.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnCancelFilterGroupMenuItems control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnCancelFilterGroupMenuItems_OnClick(object sender, EventArgs e)
        {
            try
            {
                txtFilterGroupMenuItemsByName.Text = "";
                gvGroupMenuItems.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #endregion

        #endregion

        #region Private Methods

        private void UpsertUser(object e, bool? delete = false)
        {
            _controller.UpsertUser(e, delete);
            gvUsers.DataBind();
            ddlUserMenuItemUserName.DataBind();
            gvUserMenuItems.DataBind();
            DisplayMessage("Success!", MessageType.Success);
        }

        private void ClearUserPopup()
        {
            txtUserName.Text = "";
            cbUserIsAdmin.Checked = false;
            cbUserActive.Checked = true;
        }

        private void UpsertGroup(object e, bool? delete = false)
        {
            _controller.UpsertGroup(e, delete);
            gvGroups.DataBind();
            ddlGroupMenuItemGroupName.DataBind();
            gvGroupMenuItems.DataBind();
            DisplayMessage("Success!", MessageType.Success);
        }

        private void ClearGroupPopup()
        {
            txtGroupName.Text = "";
            cbGroupIsAdmin.Checked = false;
            cbGroupActive.Checked = true;
        }

        private void UpsertUserMenuItem(object e, bool? delete = false)
        {
            _controller.UpsertUserMenuItem(e, delete);
            gvUserMenuItems.DataBind();
            DisplayMessage("Success!", MessageType.Success);
        }

        private void ClearUserMenuItemPopup()
        {
            ddlUserMenuItemName.SelectedIndex = -1;
            ddlUserMenuItemUserName.SelectedIndex = -1;
            cbUserMenuItemActive.Checked = true;
        }

        private void UpsertGroupMenuItem(object e, bool? delete = false)
        {
            _controller.UpsertGroupMenuItem(e, delete);
            gvGroupMenuItems.DataBind();
            DisplayMessage("Success!", MessageType.Success);
        }

        private void ClearGroupMenuItemPopup()
        {
            ddlGroupMenuItemName.SelectedIndex = -1;
            ddlGroupMenuItemGroupName.SelectedIndex = -1;
            cbGroupMenuItemActive.Checked = true;
        }

        #endregion

        #endregion
    }
}