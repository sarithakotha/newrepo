﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PurchReqV2.Controllers;
using PurchReqV2.Models.Entities;
using PurchReqV2.Utilities;

namespace PurchReqV2
{
    public partial class PurchaseRequisitionDisplay : PurchReqV2BasePage
    {
        #region Variables

        #region Public Variables

        #endregion

        #region Private Variables

        private PurchaseRequisitionsController _controller;

        #endregion

        #endregion

        #region Methods

        #region Public/Protected Methods

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.Title = "Purchase Requisitions";
                _controller = new PurchaseRequisitionsController(HttpContext.Current.User.Identity.Name);

                if (!IsPostBack)
                {
                    RenderPrintableView();
                }
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the ContextCreating event of the ldsDdlAddPurchReqPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqPurchaseRequisition_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlAddPurchReqPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqPurchaseRequisition_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                var requisitions = new List<PurchReq_PurchaseRequisitionStaging>();

                if (Session["RequisitionToPrint"] != null)
                {
                    var requisition = Session["RequisitionToPrint"] as List<PurchReq_PurchaseRequisition>;
                    
                    foreach(var item in requisition)
                    {
                        var newRequisition = new PurchReq_PurchaseRequisitionStaging();
                        newRequisition.SESSIONID = Session.SessionID;
                        newRequisition.TOTAL = Convert.ToDecimal(item.UNITPRC) * Convert.ToDecimal(item.UNITQTY);
                        newRequisition.UNITQTY = item.UNITQTY;
                        newRequisition.UNITPRC = item.UNITPRC;
                        newRequisition.LONGTEXT = item.LONGTEXT;
                        newRequisition.SHORTTEXT = item.SHORTTEXT;
                        newRequisition.ACCTCAT = item.ACCTCAT;
                        newRequisition.CCenter = item.CCenter;
                        newRequisition.CPFR = item.CPFR;
                        newRequisition.CRTDT = item.CRTDT;
                        newRequisition.DLVDATE = item.DLVDATE;
                        newRequisition.GLACCT = item.GLACCT;
                        newRequisition.HDRTEXT = item.HDRTEXT;
                        newRequisition.LINESEQ = item.LINESEQ;
                        newRequisition.LINESTS = item.LINESTS;
                        newRequisition.PURGROUP = item.PURGROUP;
                        newRequisition.REFPART = item.REFPART;
                        newRequisition.REQEMAIL = item.REQEMAIL;
                        newRequisition.REQUSER = item.REQUSER;
                        newRequisition.VENITEM = item.VENITEM;
                        newRequisition.VENDOR = item.VENDOR;
                        newRequisition.UOM = item.UOM;
                        newRequisition.TAXFLAG = item.TAXFLAG;
                        newRequisition.STATUS = item.STATUS;
                        newRequisition.SEQLINE = Convert.ToInt64(item.SEQLINE);
                        requisitions.Add(newRequisition);
                    }
                    e.Result = requisitions;
                }
                else if (Session["RequisitionToPrintHistorical"] != null)
                {
                    var historicalRequisition = Session["RequisitionToPrintHistorical"] as List<PurchReq_HistoricalPurchaseRequisition>;
                    
                    foreach(var item in historicalRequisition)
                    {
                        var newRequisition = new PurchReq_PurchaseRequisitionStaging();
                        newRequisition.SESSIONID = Session.SessionID;
                        newRequisition.TOTAL = Convert.ToDecimal(item.UNITPRC) * Convert.ToDecimal(item.UNITQTY);
                        newRequisition.UNITQTY = item.UNITQTY;
                        newRequisition.UNITPRC = item.UNITPRC;
                        newRequisition.LONGTEXT = item.LONGTEXT;
                        newRequisition.SHORTTEXT = item.SHORTTEXT;
                        newRequisition.ACCTCAT = item.ACCTCAT;
                        newRequisition.CCenter = item.CCenter;
                        newRequisition.CPFR = item.CPFR;
                        newRequisition.CRTDT = item.CRTDT;
                        newRequisition.DLVDATE = item.DLVDATE;
                        newRequisition.GLACCT = item.GLACCT;
                        newRequisition.HDRTEXT = item.HDRTEXT;
                        newRequisition.LINESEQ = item.LINESEQ;
                        newRequisition.LINESTS = item.LINESTS;
                        newRequisition.PURGROUP = item.PURGROUP;
                        newRequisition.REFPART = item.REFPART;
                        newRequisition.REQEMAIL = item.REQEMAIL;
                        newRequisition.REQUSER = item.REQUSER;
                        newRequisition.VENITEM = item.VENITEM;
                        newRequisition.VENDOR = item.VENDOR;
                        newRequisition.UOM = item.UOM;
                        newRequisition.TAXFLAG = item.TAXFLAG;
                        newRequisition.STATUS = item.STATUS;
                        newRequisition.SEQLINE = Convert.ToInt64(item.SEQLINE);
                        requisitions.Add(newRequisition);
                    }

                    e.Result = requisitions; 
                }
                else
                {
                    e.Result = new List<PurchReq_PurchaseRequisitionStaging>();
                }
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Renders the printable view.
        /// </summary>
        public void RenderPrintableView()
        {
            try
            {
                var requisition = Session["RequisitionToPrint"] as List<PurchReq_PurchaseRequisition>;
                var historicalRequisition = Session["RequisitionToPrintHistorical"] as List<PurchReq_HistoricalPurchaseRequisition>;
                if (requisition != null)
                {
                    var firstLineItem = requisition[0];
                    lblCostCenter.Text = firstLineItem.CCenter;
                    lblCpfrNo.Text = firstLineItem.CPFR;
                    lblPurGroup.Text = firstLineItem.PURGROUP;
                    lblPoReq.Text = firstLineItem.POREQ;
                    lblPoNumber.Text = firstLineItem.SAPPO;
                    lblStatusCode.Text = firstLineItem.STATUS;
                    lblErrorDescription.Text = firstLineItem.ERRORDESC;
                    lblHeader.Text = firstLineItem.HDRTEXT;
                    lblVendor.Text = firstLineItem.VENDOR;
                    gvAddPurchReq.AllowPaging = false;
                    gvAddPurchReq.DataBind();
                }
                else if(historicalRequisition != null)
                {
                    var firstLineItem = historicalRequisition[0];
                    lblVendor.Text = firstLineItem.VENDOR;
                    lblCostCenter.Text = firstLineItem.CCenter;
                    lblCpfrNo.Text = firstLineItem.CPFR;
                    lblPurGroup.Text = firstLineItem.PURGROUP;
                    lblPoReq.Text = firstLineItem.POREQ;
                    lblPoNumber.Text = firstLineItem.SAPPO;
                    lblStatusCode.Text = firstLineItem.STATUS;
                    lblErrorDescription.Text = firstLineItem.ERRORDESC;
                    lblHeader.Text = firstLineItem.HDRTEXT;
                    gvAddPurchReq.AllowPaging = false;
                    gvAddPurchReq.DataBind();
                }
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #endregion

        #region Private Methods
        #endregion

        #endregion
    }
}