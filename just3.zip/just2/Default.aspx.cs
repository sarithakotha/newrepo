﻿using System;
using PurchReqV2.Utilities;

namespace PurchReqV2
{
    /// <summary>
    /// Home page
    /// </summary>
    /// <seealso cref="PurchReqV2.PurchReqV2BasePage" />
    public partial class Default : PurchReqV2BasePage
    {
        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.Title = "Purchase Requisitions - Home";
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }
    }
}