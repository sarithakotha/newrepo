﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PurchReqV2.Controllers;
using PurchReqV2.Models.Entities;
using PurchReqV2.Utilities;

namespace PurchReqV2
{
    public partial class PurchaseRequisitionHistory : PurchReqV2BasePage
    {
        #region Variables

        #region Public Variables

        #endregion

        #region Private Variables

        private PurchaseRequisitionsController _controller;

        #endregion

        #endregion

        #region Methods

        #region Public/Protected Methods

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.Title = "Purchase Requisitions";
                _controller = new PurchaseRequisitionsController(HttpContext.Current.User.Identity.Name);

                if (!IsPostBack)
                {
                    gvAddPurchReq.DataBind();
                }
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #region Add Purchase Requisition Section

        /// <summary>
        /// Handles the ContextCreating event of the ldsDdlAddPurchReqPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqPurchaseRequisition_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlAddPurchReqPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqPurchaseRequisition_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetPurchaseRequisitions(HttpContext.Current.User.Identity.Name,
                    (!String.IsNullOrEmpty(txtGvAddPurchReqVendor.Text)) ? txtGvAddPurchReqVendor.Text : null,
                    !String.IsNullOrEmpty(txtGvAddPurchReqRequisitionStartDate.Text) ? txtGvAddPurchReqRequisitionStartDate.Text : null,
                    !String.IsNullOrEmpty(txtGvAddPurchReqSequence.Text) ? txtGvAddPurchReqSequence.Text : null,
                    !String.IsNullOrEmpty(txtGvPurchaseRequisitionNumber.Text) ? txtGvPurchaseRequisitionNumber.Text : null,
                    !String.IsNullOrEmpty(txtGvRequisitioner.Text) ? txtGvRequisitioner.Text : null,
                    !String.IsNullOrEmpty(txtGvCostCenter.Text) ? txtGvCostCenter.Text : null,
                    !String.IsNullOrEmpty(txtGvCpfr.Text) ? txtGvCpfr.Text : null,
                    !String.IsNullOrEmpty(txtGvTrackingNumber.Text) ? txtGvTrackingNumber.Text : null,
                    !String.IsNullOrEmpty(txtGvStatus.Text) ? txtGvStatus.Text : null);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the ContextCreating event of the ldsGvAddPurchReqHistory control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsGvAddPurchReqHistory_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsGvAddPurchReqHistory control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsGvAddPurchReqHistory_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetHistoricalPurchaseRequisitions(HttpContext.Current.User.Identity.Name,
                    (!String.IsNullOrEmpty(txtHistoricalGvVendor.Text)) ? txtHistoricalGvVendor.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvCreateDate.Text) ? txtHistoricalGvCreateDate.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvSequenceNumber.Text) ? txtHistoricalGvSequenceNumber.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvPurchaseRequisition.Text) ? txtHistoricalGvPurchaseRequisition.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvRequisitioner.Text) ? txtHistoricalGvRequisitioner.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvCostCenter.Text) ? txtHistoricalGvCostCenter.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvCpfr.Text) ? txtHistoricalGvCpfr.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvTrackingNumber.Text) ? txtHistoricalGvTrackingNumber.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvStatus.Text) ? txtHistoricalGvStatus.Text : null);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnAddPurchReqSubmit control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnAddPurchReqSubmit_OnClick(object sender, EventArgs e)
        {
            try
            {
                _controller.MigrateStagingPurchaseRequisitionToProduction(Session.SessionID);
                gvAddPurchReq.DataBind();
                return;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnAddPurchReqCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnAddPurchReqCancel_OnClick(object sender, EventArgs e)
        {
            try
            {
                _controller.DeleteStagedPurchaseRequisitionsBySessionID(Session.SessionID);
                gvAddPurchReq.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnFilterGvAddPurchReqHistoryCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnFilterGvAddPurchReqHistoryCancel_OnClick(object sender, EventArgs e)
        {
            try
            {
                txtHistoricalGvCostCenter.Text = String.Empty;
                txtHistoricalGvCpfr.Text = String.Empty;
                txtHistoricalGvCreateDate.Text = String.Empty;
                txtHistoricalGvPurchaseRequisition.Text = String.Empty;
                txtHistoricalGvRequisitioner.Text = String.Empty;
                txtHistoricalGvSequenceNumber.Text = String.Empty;
                txtHistoricalGvTrackingNumber.Text = String.Empty;
                txtHistoricalGvVendor.Text = String.Empty;
                txtHistoricalGvStatus.Text = String.Empty;
                gvAddPurchReqHistory.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnFilterGvAddPurchReqHistory control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnFilterGvAddPurchReqHistory_OnClick(object sender, EventArgs e)
        {
            try
            {
                gvAddPurchReqHistory.DataBind();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #endregion

        /// <summary>
        /// Handles the OnClick event of the btnExportPurchaseRequisitionHistory control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="ImageClickEventArgs"/> instance containing the event data.</param>
        protected void btnExportPurchaseRequisitionHistory_OnClick(object sender, ImageClickEventArgs e)
        {
            try
            {
                var result = _controller.GetHistoricalPurchaseRequisitions(HttpContext.Current.User.Identity.Name,
                    (!String.IsNullOrEmpty(txtHistoricalGvVendor.Text)) ? txtHistoricalGvVendor.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvCreateDate.Text) ? txtHistoricalGvCreateDate.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvSequenceNumber.Text) ? txtHistoricalGvSequenceNumber.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvPurchaseRequisition.Text) ? txtHistoricalGvPurchaseRequisition.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvRequisitioner.Text) ? txtHistoricalGvRequisitioner.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvCostCenter.Text) ? txtHistoricalGvCostCenter.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvCpfr.Text) ? txtHistoricalGvCpfr.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvTrackingNumber.Text) ? txtHistoricalGvTrackingNumber.Text : null,
                    !String.IsNullOrEmpty(txtHistoricalGvStatus.Text) ? txtHistoricalGvStatus.Text : null);
                DownloadExcelWorkbook(_controller.GenerateExcelDocument(result, "Historical Purchase Requisitions"), "PurchaseRequisitionHistory");
            }
            catch (Exception ex)
            {
                HandleException(ex);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnExportProcessingPurchaseRequisitionHistory control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.ImageClickEventArgs"/> instance containing the event data.</param>
        /// <returns>N/A</returns>
        protected void btnExportProcessingPurchaseRequisitionHistory_OnClick(object sender, ImageClickEventArgs e)
        {
            try
            {
                var result = _controller.GetPurchaseRequisitions(HttpContext.Current.User.Identity.Name,
                    (!String.IsNullOrEmpty(txtGvAddPurchReqVendor.Text)) ? txtGvAddPurchReqVendor.Text : null,
                    !String.IsNullOrEmpty(txtGvAddPurchReqRequisitionStartDate.Text) ? txtGvAddPurchReqRequisitionStartDate.Text : null,
                    !String.IsNullOrEmpty(txtGvAddPurchReqSequence.Text) ? txtGvAddPurchReqSequence.Text : null,
                    !String.IsNullOrEmpty(txtGvPurchaseRequisitionNumber.Text) ? txtGvPurchaseRequisitionNumber.Text : null,
                    !String.IsNullOrEmpty(txtGvRequisitioner.Text) ? txtGvRequisitioner.Text : null,
                    !String.IsNullOrEmpty(txtGvCostCenter.Text) ? txtGvCostCenter.Text : null,
                    !String.IsNullOrEmpty(txtGvCpfr.Text) ? txtGvCpfr.Text : null,
                    !String.IsNullOrEmpty(txtGvTrackingNumber.Text) ? txtGvTrackingNumber.Text : null,
                    !String.IsNullOrEmpty(txtGvStatus.Text) ? txtGvStatus.Text : null);
                DownloadExcelWorkbook(_controller.GenerateExcelDocument(result, "Historical Purchase Requisitions"), "PurchaseRequisitionHistory");
            }
            catch (Exception ex)
            {
                HandleException(ex);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the ibCopyProcessingPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void ibCopyProcessingPurchaseRequisition_OnClick(object sender, EventArgs e)
        {
            try
            {
                var sequenceKeyRow = 1;
                var requisitionerRow = 20;
                var copyButton = sender as ImageButton;
                var copyButtonRow = copyButton.BindingContainer as GridViewRow;
                var sequenceKey = copyButtonRow.Cells[sequenceKeyRow].Text;
                var requisitioner = copyButtonRow.Cells[requisitionerRow].Text;
                var purchaseRequisition = _controller.GetPurchaseRequisitions(null, null, null, sequenceKey, null, requisitioner);
                Session["CopiedRequisitionHistorical"] = null;
                Session["CopiedRequisition"] = purchaseRequisition;

                Response.Redirect("~/PurchaseRequisitions.aspx");
            }
            catch (Exception ex)
            {
                HandleException(ex);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the ibPrintProcessingPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void ibPrintProcessingPurchaseRequisition_OnClick(object sender, EventArgs e)
        {
            try
            {
                var sequenceKeyRow = 1;
                var requisitionerRow = 20;
                var copyButton = sender as ImageButton;
                var copyButtonRow = copyButton.BindingContainer as GridViewRow;
                var sequenceKey = copyButtonRow.Cells[sequenceKeyRow].Text;
                var requisitioner = copyButtonRow.Cells[requisitionerRow].Text;
                var purchaseRequisition = _controller.GetPurchaseRequisitions(null, null, null, sequenceKey, null, requisitioner);
                Session["RequisitionToPrintHistorical"] = null;
                Session["RequisitionToPrint"] = purchaseRequisition;

                Response.Redirect("~/Display.aspx");
            }
            catch (Exception ex)
            {
                HandleException(ex);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the ibCopyProcessingPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void ibCopyProcessingPurchaseRequisitionHistorical_OnClick(object sender, EventArgs e)
        {
            try
            {
                var sequenceKeyRow = 1;
                var requisitionerRow = 20;
                var copyButton = sender as ImageButton;
                var copyButtonRow = copyButton.BindingContainer as GridViewRow;
                var sequenceKey = copyButtonRow.Cells[sequenceKeyRow].Text;
                var requisitioner = copyButtonRow.Cells[requisitionerRow].Text;
                var purchaseRequisition = _controller.GetHistoricalPurchaseRequisitions(null, null, null, sequenceKey, null, requisitioner);
                Session["CopiedRequisition"] = null;
                Session["CopiedRequisitionHistorical"] = purchaseRequisition;

                Response.Redirect("~/PurchaseRequisitions.aspx");
            }
            catch (Exception ex)
            {
                HandleException(ex);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the ibPrintProcessingPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void ibPrintProcessingPurchaseRequisitionHistorical_OnClick(object sender, EventArgs e)
        {
            try
            {
                var sequenceKeyRow = 1;
                var requisitionerRow = 20;
                var copyButton = sender as ImageButton;
                var copyButtonRow = copyButton.BindingContainer as GridViewRow;
                var sequenceKey = copyButtonRow.Cells[sequenceKeyRow].Text;
                var requisitioner = copyButtonRow.Cells[requisitionerRow].Text;
                var purchaseRequisition = _controller.GetHistoricalPurchaseRequisitions(null, null, null, sequenceKey, null, requisitioner);
                Session["RequisitionToPrint"] = null;
                Session["RequisitionToPrintHistorical"] = purchaseRequisition;

                Response.Redirect("~/Display.aspx");
            }
            catch (Exception ex)
            {
                HandleException(ex);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnFilterReqRecent control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnFilterReqRecent_OnClick(object sender, EventArgs e)
        {
            try
            {
                gvAddPurchReq.DataBind();
            }
            catch (Exception ex)
            {
                HandleException(ex);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnFilterReqRecentCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnFilterReqRecentCancel_OnClick(object sender, EventArgs e)
        {
            try
            {
                txtGvAddPurchReqVendor.Text = String.Empty;
                txtGvAddPurchReqSequence.Text = String.Empty;
                txtGvAddPurchReqRequisitionStartDate.Text = String.Empty;
                txtGvCostCenter.Text = String.Empty;
                txtGvRequisitioner.Text = String.Empty;
                txtGvCpfr.Text = String.Empty;
                txtGvTrackingNumber.Text = String.Empty;
                txtGvPurchaseRequisitionNumber.Text = String.Empty;
                txtGvStatus.Text = String.Empty;
                gvAddPurchReq.DataBind();
            }
            catch (Exception ex)
            {
                HandleException(ex);
            }
        }

        #endregion

        #region Private Methods

        #endregion

        #endregion
    }
}